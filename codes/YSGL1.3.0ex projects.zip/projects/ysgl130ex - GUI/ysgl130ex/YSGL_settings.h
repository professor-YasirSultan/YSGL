#ifndef YSGL_settings_H
#define YSGL_settings_H

#include <YSGLall.h>

#define YSGL_forms
#define YSGL_projectName ysgl130ex

#define YSGL_scr_width 800
#define YSGL_scr_height 600

int YSGL_main_entry_point2();
#endif