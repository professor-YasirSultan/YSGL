
#include <iostream>
#include <cstdio>
#include <cstdlib>

#include <cstring>
#include <string>

using namespace std;