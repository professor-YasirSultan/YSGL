#ifndef YSGlobalVars
#define YSGlobalVars

#include "YSGLall.h"

extern  HDC			hDC;
extern  HGLRC		hRC;
extern  HWND		hWnd;
extern  HINSTANCE	hInstance;

extern bool	keys[256];			// Array Used For The Keyboard Routine
extern bool	active;
extern bool	fullscreen;

extern GLuint	base;
extern GLYPHMETRICSFLOAT gmf[256];

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc
int YSGL_init_Caller(GLvoid);

GLvoid ReSizeGLScene(GLsizei width, GLsizei height);
GLvoid KillGLWindow(GLvoid);
BOOL CreateGLWindow(string title="YSGL", int width=640, int height=480, int bits=16, bool fullscreenflag=false);
LRESULT CALLBACK WndProc(	HWND	hWnd,UINT	uMsg, WPARAM	wParam, LPARAM	lParam);
void ysmb(string str, string title="YSGL msgBox");
bool fullScreenMessegeBox();

// --------------------------------------------------------------------

//void YSGLLookAt(VecYS eye , VecYS target);
//void YSGLLookAt(VecYS eye , double theta , double phi);
GLvoid BuildFont(GLvoid);
GLvoid ysPrintf(const char *fmt, ...);

// --------------------------------------------------------------------

int YSGL_init_Caller();
int YSGL_mainGL_Caller();
int WINAPI ysEnrty();
int YSGL_main_entry_point(int scr_width, int scr_height);

#endif