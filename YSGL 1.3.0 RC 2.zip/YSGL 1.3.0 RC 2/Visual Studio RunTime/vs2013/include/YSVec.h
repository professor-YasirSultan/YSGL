#ifndef YSVec_H
#define YSVec_H

#include <math.h>
#include <iostream>
using namespace std;

class YSVec
{
public:
	double x, y, z;
	YSVec(double xx = 0, double yy = 0, double zz = 0);
	void set(double xx = 0, double yy = 0, double zz = 0);

	YSVec operator+(const YSVec& b);
	YSVec operator-(const YSVec& b);

	YSVec operator+=(const YSVec& b);
	YSVec operator-=(const YSVec& b);

	double operator^(const YSVec& b);
	YSVec operator*(const YSVec& b);

	YSVec operator*(const double& b);
	YSVec operator/ (const double& b);
	YSVec operator*= (const double& b);
	YSVec operator/= (const double& b);

	YSVec operator- ();

	double abs();
	double length();
	double magnitude();

	YSVec norm();
	YSVec direction();
	YSVec unit();

	void printOnConsole();

	void draw(float W = 10);

	friend ostream& operator<< (ostream& os, const YSVec& b);
	friend istream& operator>> (istream& is, YSVec& b);

	friend YSVec operator*(const double& b, const YSVec& v);
	/*
	YSVec Reflect(YSVec planeNorm);
	YSVec Rotate(YSVec axis, double angle);
	*/
};

#endif
