#ifndef ysHelper_H
#define ysHelper_H

int yshFileExist(const char* fileName);

#endif ysHelper_H