#ifndef YSColor_H
#define YSColor_H

class YSColor
{
public:
	float r, g, b;
	YSColor(float r = 1.0f, float g = 1.0f, float b = 1.0f);
	
	//same as glColor3f
	void select();
};

#endif