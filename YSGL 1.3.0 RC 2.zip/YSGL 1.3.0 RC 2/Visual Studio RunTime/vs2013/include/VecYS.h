#ifndef VECYS_H
#define VECYS_H

#include <math.h>

#include <iostream>
using namespace std;

class arr3v
{
    public:
    double a,b,c;
    arr3v(double aa=0,double bb=0,double cc=0) {a=aa;b=bb;c=cc;}
    void print()
    {
        cout << "( " << a << " , " << b << " , " << c << " )" << endl;
    }
};

class VecYS
{
    public:
        double x,y,z;
		double Pi;
		double RadInDeg;

        VecYS(double xx=0,double yy=0,double zz=0);
        void sett(double xx=0,double yy=0,double zz=0);

        VecYS operator+(const VecYS& b);
		VecYS operator*(const VecYS& b);
		double operator^(const VecYS& b);

        VecYS operator*(const double& b);
		VecYS operator/ (const double& b);

		VecYS operator- ();

        VecYS dir2vec(double theta);
        double phi(); //ver2angle() , vec2angle();

        void sphericalSetter(double r, double theta, double phi);
        arr3v sphericalGetter();

        double abs();
        VecYS norm();

        void print();
		string toString();
		char* toStringC();

		void draw(float W = 10);

		friend ostream& operator<< (ostream& os, const VecYS& b);
		friend istream& operator>> (istream& is, VecYS& b);


    protected:
    private:

};

#endif // VECYS_H
