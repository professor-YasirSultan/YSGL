#ifndef YS3dModel_OBJ_H
#define YS3dModel_OBJ_H
#include "YSGLall.h"
using namespace std;
class YS3dModel_OBJ
{
public:
	YS3dModel_OBJ();
	void load(const char* objFileName, const char* textureFileName );
	void load(string objFileName, string textureFileName);
	void load(const char* objFileName, const char* textureFileName, const char* folder);
	void load(const char* objFileName, const char* textureFileName, const char* SuperFolder, const char* SubFolder);
	void load(string objFileName, string textureFileName, string SuperFolder, string SubFolder);
	void load(string objFileName, string textureFileName, string SuperFolder);
	void draw();
	float sc;
	
private:
	int ysModelInt;
	bool modelLoaded;

};

#endif