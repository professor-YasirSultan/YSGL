﻿#pragma once
//
//class YSConst {
//public:
//	// Physics constants
//	static constexpr double GRAVITY = 9.81; // تسارع الجاذبية الأرضية (م/ث^2)
//	static constexpr double SPEED_OF_LIGHT = 299792458; // سرعة الضوء في الفراغ (م/ث)
//	static constexpr double PLANCK_CONSTANT = 6.62607015e-34; // ثابت بلانك (ج.ث)
//	static constexpr double BOLTZMANN_CONSTANT = 1.380649e-23; // ثابت بولتزمان (ج/ك)
//	static constexpr double ELEMENTARY_CHARGE = 1.602176634e-19; // الشحنة الأساسية للالكترون (كولوم)
//	static constexpr double ELECTRON_MASS = 9.10938356e-31; // كتلة الإلكترون (كغ)
//	static constexpr double PROTON_MASS = 1.6726219e-27; // كتلة البروتون (كغ)
//	static constexpr double NEUTRON_MASS = 1.6749275e-27; // كتلة النيوترون (كغ)
//	static constexpr double AVOGADRO_CONSTANT = 6.02214076e23; // ثابت افوغادرو (1/مول)
//	static constexpr double FARADAY_CONSTANT = 96485.33212; // ثابت فاراداي (كولوم/مول)
//	static constexpr double GAS_CONSTANT = 8.314462618; // الثابت العام للغازات (ج/مول.ك)
//	static constexpr double STANDRAD_ATMOSPHERE_PRESSURE = 101325; // الضغط الجوي القياسي (باسكال)
//	static constexpr double BOLTZMANN_CONSTANT_IN_EV = 8.617333262e-5; // ثابت بولتزمان بالإلكترون-فولت/كلفن (إلكترون-فولت/ك)
//
//	// Math constants
//	static constexpr double pi = 3.14159265358979323846; // النسبة المئوية لمحيط الدائرة إلى قطرها
//	static constexpr double e = 2.71828182845904523536; // العدد النابع الطبيعي
//};
//
//class YSConst {
//public:
//	// تسارع الجاذبية الأرضية
//	// g = 9.81 m/s
//	static const double GRAVITY;
//
//};


class YSConst {
public:
	// تسارع الجاذبية الأرضية
	// g = 9.81 m/s
	static const double GRAVITY;

	// سرعة الضوء في الفراغ
	// c = 299792458 m/s
	static const double SPEED_OF_LIGHT;

	// ثابت بلانك
	// h = 6.62607015e-34 J·s
	static const double PLANCK_CONSTANT;

	// ثابت بولتزمان
	// k = 1.380649e-23 J/K
	static const double BOLTZMANN_CONSTANT;

	// الشحنة الأساسية للالكترون
	// e = 1.602176634e-19 C
	static const double ELEMENTARY_CHARGE;

	// كتلة الإلكترون
	// me = 9.10938356e-31 kg
	static const double ELECTRON_MASS;

	// كتلة البروتون
	// mp = 1.6726219e-27 kg
	static const double PROTON_MASS;

	// كتلة النيوترون
	// mn = 1.6749275e-27 kg
	static const double NEUTRON_MASS;

	// ثابت افوغادرو
	// NA = 6.02214076e23 1/mol
	static const double AVOGADRO_CONSTANT;

	// ثابت فاراداي
	// F = 96485.33212 C/mol
	static const double FARADAY_CONSTANT;

	// الثابت العام للغازات
	// R = 8.314462618 J/mol·K
	static const double GAS_CONSTANT;

	// الضغط الجوي القياسي
	// p0 = 101325 Pa
	static const double STANDRAD_ATMOSPHERE_PRESSURE;

	// ثابت بولتزمان بالإلكترون-فولت/كلفن
	// k = 8.617333262e-5 eV/K
	static const double BOLTZMANN_CONSTANT_IN_EV;

	// النسبة المئوية لمحيط الدائرة إلى قطرها
	// π = 3.14159265358979323846;
	static const double pi;

	// العدد النابع الطبيعي
	// e = 2.71828182845904523536
	static const double e;
};
