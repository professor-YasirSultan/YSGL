#pragma once

#ifndef OBJLOADER
#define OBJLOADER

struct coordinate {
	float x, y, z;
	coordinate(float a, float b, float c) : x(a), y(b), z(c) {};
	coordinate(float a, float b) :x(a), y(b), z(0) {};
};
//for faces, it can contain triangles and quads as well, the four variable contain which is that
struct face {
	int facenum[4];
	bool four; // if face has 4 Verteces
	int faces[4];
	int texture_coord[4];
	face(int facen,int b2 ,int b3, int f1, int f2, int f3 ,int t1 , int t2 ,int t3) {  //constructor for triangle
		faces[0] = f1;
		faces[1] = f2;
		faces[2] = f3;
		facenum[0] = facen;
		facenum[1] = b2;
		facenum[2] = b3;
		texture_coord[0] = t1;
		texture_coord[1] = t2;
		texture_coord[2] = t3;
		four = false;
	}
	face(int facen, int f1, int f2, int f3, int f4){ //overloaded constructor for quad
		faces[0] = f1;
		faces[1] = f2;
		faces[2] = f3;
		faces[3] = f4;
		four = true;
	}
};

int loadObject(const char* filename, const char* texture_image_path);
#endif // !OBJLOADER
