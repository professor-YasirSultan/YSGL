#ifndef Header_YH
#define Header_YH

#include <YSGLallNeHe.h>

void ysmb(string str, string title="YSGL msgBox");
bool fullScreenMessegeBox();

// --------------------------------------------------------------------
void YSGLLookAt(VecYS eye , VecYS target);
void YSGLLookAt(VecYS eye , double theta , double phi);
GLvoid BuildFont(GLvoid);
GLvoid ysPrintf(const char *fmt, ...);

// --------------------------------------------------------------------

int WINAPI ysEnrty();

#endif