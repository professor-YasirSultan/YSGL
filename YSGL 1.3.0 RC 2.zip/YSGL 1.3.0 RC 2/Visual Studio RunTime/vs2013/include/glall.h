#ifndef YSGLall_h
#define YSGLall_h


#include <windows.h>
#include <gl.h>
#include <glu.h>
#include <glut.h>
#include <glaux.h>
#include <cmath>

#include <YSGLio.h>

using namespace std;
//#   pragma comment (lib, "aboutLIB.lib")
//#   pragma comment (lib, "YSCameraLIB.lib")
//#   pragma comment (lib, "YSTextureLIB.lib")
#   pragma comment (lib, "opengl32.lib")   
#   pragma comment (lib, "glu32.lib")      
#   pragma comment (lib, "GLAUX.LIB")
#   pragma comment (lib, "glut32.lib")      

#endif