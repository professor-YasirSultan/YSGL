#include <iostream>
#include <chrono>

class YSTime
{
public:

	double deltaTimeFromStart, deltaTime, FPS, FPS_average, FPS_max, FPS_min;
	int frame_id, printStatus , clearEveryFrame;

	YSTime();

	void init();

	void update();

	void print1();
	void print2();
	
};