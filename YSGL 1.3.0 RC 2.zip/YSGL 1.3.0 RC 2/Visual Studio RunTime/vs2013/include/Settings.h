#ifndef YSGL_Settings_H
#define YSGL_Settings_H
#include <string>
using namespace std;

//string Window_Title = "YSGL Example";

#endif