#ifndef YSTexture_H
#define YSTexture_H


#include "YSGLall.h"
class YSTexture
{
public:
	YSTexture();
	//YSTexture(char texFilename[]);
	//YSTexture(string texFilename);

	void load(char texFilename[]);
	void load(char texFilename[] , char Folder[]);
	void load(string texFilename);
	void load(string texFilename, string Folder);

	void draw(float sc=1 ,float repeat_x=1 , float repeat_y=1);

	void activate();
	void deActivate();
	
private:
	int load_private();
	int LoadGLTextures();
	AUX_RGBImageRec* LoadBMP();
	void filter(GLenum f);

	char fileName[300];
	GLuint	textureGLuint;
	int texStatus;
};


#endif