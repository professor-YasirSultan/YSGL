#ifndef YSGLaux_H
#define YSGLaux_H
#include "YSGLall.h"

void ysDrawTri();

void ysDrawCube(GLfloat sc = 1);
void ysDrawCubeNoColor(GLfloat sc = 1);
void ysDrawCubeRotating(float x = 0, float y = 0, float z = 0, GLfloat sc = 1);

void ysDrawSphere(double radius = 1, int slices = 20, int stacks = 20);

void ysColor3i(int R=0, int G=0, int B=0);

void ysDrawPyramid();

void ysRotAutoBegin();
void ysRotAutoEnd();

void ysDrawGroundPlane(GLfloat sc = 10);

double ysSinD(double thetaDeg);
double ysCosD(double thetaDeg);

double ysDeg2Rad(double thetaDeg);
double ysRad2Deg(double thetaRad);

#endif