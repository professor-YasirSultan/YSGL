#ifndef YSGLall_h
#define YSGLall_h

#include <windows.h>
#include <gl.h>
#include <glu.h>
#include <glut.h>
#include <glaux.h>
#include <cmath>

#include <YSGLio.h>

#include <Header.h>
#include <YSGLaux.h>
#include <about.h>
#include <YS3dModel_OBJ.h>
#include <YS3dModel_3DS.h>
#include <YSTexture.h>
#include <YSVec.h>
#include <Camera.h>
#include "YSHidMac.h"

using namespace std;
#   pragma comment (lib, "YSGLlib.lib")   
//#   pragma comment (lib, "aboutLIB.lib")
//#   pragma comment (lib, "YSCameraLIB.lib")
//#   pragma comment (lib, "YSTextureLIB.lib")
#   pragma comment (lib, "opengl32.lib")   
#   pragma comment (lib, "glu32.lib")      
#   pragma comment (lib, "GLAUX.LIB")
#   pragma comment (lib, "glut32.lib")      
#   pragma comment (lib, "Windows.lib")      

#endif