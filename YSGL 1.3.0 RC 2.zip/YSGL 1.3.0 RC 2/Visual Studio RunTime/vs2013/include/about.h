#include "YSGLall.h"

void YSGLaboutFormShow();
string ysgl_about_str();
void ysgl_about_mb();
void ysgl_openGL_ver_mb();
void ysgl_ver_mb();
void MessageBoxYS(
	_In_opt_ HWND hWnd,
	string lpText,
	string lpCaption,
	_In_ UINT uType);