﻿#pragma once
class YSConsts
{
public:

	static const double pi;
	static const double e;
	static const double c;
	static const double G;
	static const double h;
	static const double NA;
	static const double R;
	static const double q;
	static const double me;
	static const double mp;
	static const double epsilon0;
	static const double mu0;
};

/*

pi - 3.14159265358979 
ratio of circle's circumference to its diameter

e - 2.718281828459045 
base of natural logarithms

c - 299792458 m/s 
Speed of light in vacuum

G - 6.67408×10−11 N m2/kg2 
Gravitational constant

h - 6.62607015×10−34 J·s 
Planck constant

k - 1.380649×10−23 J/K 
Boltzmann constant

NA - 6.02214076×1023 1/mol 
Avogadro constant

R - 8.3144598 J/(mol·K) 
Universal gas constant

q - 1.60217733×10−19 C 
Elementary charge

m_e - 9.1093837015×10−31 kg 
Electron rest mass

m_p -1.67262192369×10−27 kg 
Proton rest mass

ɛ_0 - 8.854187817×10−12 F/m 
Vacuum permittivity

μ_0 - 1.2566370614359 × 10−6 N/A2
Vacuum permeability
*/