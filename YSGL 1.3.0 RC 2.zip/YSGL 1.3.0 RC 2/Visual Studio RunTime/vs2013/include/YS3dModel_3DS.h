#pragma once
#include <Model_3DS.h>
class YS3dModel_3DS : public Model_3DS
{
public:
	YS3dModel_3DS();
	/*
	void load(const char* objFileName, const char* textureFileName);
	void load(string objFileName, string textureFileName);
	void load(const char* objFileName, const char* textureFileName, const char* folder);
	void load(const char* objFileName, const char* textureFileName, const char* SuperFolder, const char* SubFolder);
	void load(string objFileName, string textureFileName, string SuperFolder, string SubFolder);
	void load(string objFileName, string textureFileName, string SuperFolder);
	*/
	void Load(char *name);
	void LoadTexBMP(int i,char *name);
	void LoadTexAllBMP(char *name);
	void draw();
	float sc;

private:
	int ysModelInt;
	bool modelLoaded;
};

