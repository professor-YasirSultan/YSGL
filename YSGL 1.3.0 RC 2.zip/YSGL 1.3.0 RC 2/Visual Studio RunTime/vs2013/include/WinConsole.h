#include <glall.h>

void MessageBoxYS(
    _In_opt_ HWND hWnd,
    _In_opt_ LPCSTR lpText,
    _In_opt_ LPCSTR lpCaption,
    _In_ UINT uType)
{

#ifdef UNICODE
//#define MessageBox  MessageBoxW
MessageBoxW(
    hWnd,
    (LPCWSTR)lpText,
    (LPCWSTR)lpCaption,
    uType);
#else
//#define MessageBox  MessageBoxA
MessageBoxA(
    hWnd,
    lpText,
    lpCaption,
    uType);
#endif // !UNICODE
}